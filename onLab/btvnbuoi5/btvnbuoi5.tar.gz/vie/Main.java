package nguyentientho.techmasterndcjavacore14.buoi5.vie;

public class Main {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                break;
            } else System.out.println("số lẻ");
        }
    }
}
