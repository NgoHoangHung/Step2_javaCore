package hdt;

public class Cross {

}
