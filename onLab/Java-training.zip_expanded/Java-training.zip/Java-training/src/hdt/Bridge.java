package hdt;

public class Bridge {

}
