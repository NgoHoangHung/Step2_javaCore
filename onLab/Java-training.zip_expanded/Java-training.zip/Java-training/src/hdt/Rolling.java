package hdt;

public interface Rolling {

}
