package hdt;

public interface Walking {

}
