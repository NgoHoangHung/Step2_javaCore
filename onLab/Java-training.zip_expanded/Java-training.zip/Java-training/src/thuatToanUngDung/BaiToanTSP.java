package thuatToanUngDung;

public class BaiToanTSP {
	int[] iRes = new int[1000];
	boolean[] bVisited = new boolean[1000];
	`r
	
	void Try(int k) {
		// thăm thành phố thứ k
		for( int )
	}
}
