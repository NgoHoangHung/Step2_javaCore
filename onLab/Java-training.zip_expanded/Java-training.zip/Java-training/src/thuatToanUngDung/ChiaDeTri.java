package thuatToanUngDung;

public class ChiaDeTri {
	public static void main(String[] args) {
	while()	
	}
	
	
	public static boolean checkFx(double x) {
		if(x*x*x - 100*x*x +20*x +30 <= 10e-8)
		return true;
		else 
			return false;
	}
	
	
}
