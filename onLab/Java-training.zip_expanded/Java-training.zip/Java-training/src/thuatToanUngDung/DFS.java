package thuatToanUngDung;

public class DFS {
	int[] Adj = new int[1001];
	int u;
	
	public int[] getAdj() {
		return Adj;
	}
	public void setAdj(int[] adj) {
		Adj = adj;
	}
	public int getU() {
		return u;
	}
	public void setU(int u) {
		this.u = u;
	}
	
}
