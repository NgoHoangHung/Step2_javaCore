package Bellman_ford;

public class Edge {

}
