package chap06_OOP_Advance;

public interface Bird {
	public void fly(teacher abc);
}
