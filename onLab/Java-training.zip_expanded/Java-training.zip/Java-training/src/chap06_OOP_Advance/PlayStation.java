package chap06_OOP_Advance;

public class PlayStation {
	public void play(Character Obj) {
		Obj.run();
		Obj.sleep();
	}
}
