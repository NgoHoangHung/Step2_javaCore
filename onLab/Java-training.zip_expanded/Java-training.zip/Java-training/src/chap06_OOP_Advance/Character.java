package chap06_OOP_Advance;

public interface Character {
	public void run();
	public void sleep();
}
